use "pubs";
go

IF (OBJECT_ID('fk2', 'F') IS NOT NULL) BEGIN ALTER TABLE dbo.DIM_TITLE DROP CONSTRAINT fk2 END 

DROP TABLE IF EXISTS dbo.DIM_PUBS
DROP TABLE IF EXISTS dbo.DIM_DATE
--create
create table [DIM_PUBS] (
	PUB_KEY		int identity(1,1) primary key, 
	PUB_ID		varchar(4) not null, 
	PUB_NAME	varchar(40) not null
) 
go
create table [DIM_DATE] (
	DATE_KEY		int identity(1,1) primary key, 
	DATE_STR		char(8) not null, 
	DATE_YEAR		char(4) not null,
	DATE_MONTH		char(2) not null,
	DATE_QTR		char(2) not null
) 
go
--insert
insert into [DIM_PUBS] (PUB_ID, PUB_NAME)
select pub_id, pub_name from publishers

insert into [DIM_DATE] (DATE_STR, DATE_YEAR, DATE_MONTH, DATE_QTR)
--select datepart(yyyy, ord_date) + datepart(mm, ord_date) + datepart(dd, ord_date), datepart(yyyy, ord_date), datepart(mm, ord_date), datepart(quarter, ord_date) from sales
select convert(varchar, ord_date, 112) + datepart(mm, ord_date) + datepart(dd, ord_date), datepart(yyyy, ord_date), datepart(mm, ord_date), datepart(quarter, ord_date) from sales
--SELECT convert(varchar, getdate(), 112) -- yyyymmdd

--show
--select * from [DIM_PUBS]
--select * from [DIM_DATE]
--select * from titles

------------------------------------------
--delete foreign/primary keys
IF (OBJECT_ID('fk1', 'F') IS NOT NULL) BEGIN ALTER TABLE dbo.DIM_TITLE DROP CONSTRAINT fk1 END
IF (OBJECT_ID('fk2', 'F') IS NOT NULL) BEGIN ALTER TABLE dbo.DIM_TITLE DROP CONSTRAINT fk2 END 
IF (OBJECT_ID('pk1', 'F') IS NOT NULL) BEGIN ALTER TABLE dbo.DIM_TITLE DROP CONSTRAINT pk1 END 
IF (OBJECT_ID('pk2', 'F') IS NOT NULL) BEGIN ALTER TABLE dbo.DIM_TITLE DROP CONSTRAINT pk2 END 
IF (OBJECT_ID('pk3', 'F') IS NOT NULL) BEGIN ALTER TABLE dbo.DIM_TITLE DROP CONSTRAINT pk3 END 
IF (OBJECT_ID('pk4', 'F') IS NOT NULL) BEGIN ALTER TABLE dbo.DIM_TITLE DROP CONSTRAINT pk4 END 
IF (OBJECT_ID('pk5', 'F') IS NOT NULL) BEGIN ALTER TABLE dbo.DIM_TITLE DROP CONSTRAINT pk5 END 
IF (OBJECT_ID('pk6', 'F') IS NOT NULL) BEGIN ALTER TABLE dbo.DIM_TITLE DROP CONSTRAINT pk6 END 
GO 
--delete table
DROP TABLE IF EXISTS dbo.DIM_TITLE_TYPE
DROP TABLE IF EXISTS dbo.DIM_TITLE
DROP TABLE IF EXISTS dbo.DIM_STORES
DROP TABLE IF EXISTS dbo.DIM_ZIP_CITY
DROP TABLE IF EXISTS dbo.DIM_ZIP_STATE
DROP TABLE IF EXISTS dbo.FACT_SALES
--create tables
create table [DIM_TITLE_TYPE] (
	TITLE_TYPE_KEY		int identity(1,1), 
	TITLE_ID			char(2),
	[TYPE_NAME]			nvarchar(12),
	constraint pk1 primary key (TITLE_TYPE_KEY),
	--unique (TITLE_ID)
) 
go
create table [DIM_TITLE] (
	TITLE_KEY		int identity(1,1), 
	TITLE_NAME		varchar(80),	
	TITLE_TYPE_ID	char(2) ,					--fk dim_title_type, TITLE_TYPE_KEY
	TITLE_NUMBER	int,
	PUB_KEY			varchar(4),						--fk dim_pubs, PUB_KEY
	constraint pk2 primary key (TITLE_KEY),
) 
go
create table [DIM_STORES] (
	STORE_ID		char(4), 
	STORE_NAME		varchar(40),
	ZIP_CODE		char(5),
	constraint pk3 primary key (STORE_ID)
) 
go
create table [DIM_ZIP_CITY] (
	ZIP_CODE		char(5), 
	ZIP_CITY		varchar(20),
	constraint pk4 primary key (ZIP_CODE)
) 
go
create table [DIM_ZIP_STATE] (
	ZIP_CODE		char(5), 
	STATE_CODE		char(2),
	constraint pk5 primary key (ZIP_CODE)
) 
go
create table [FACT_SALES] (
	FATCT_KEY		int identity(1,1),
	STORE_ID		varchar(4), 
	ZIP_CODE_Key1	varchar(5),
	ZIP_CODE_key2	varchar(5),
	TITLE_KEY		int,
	TITLE_TYPE_KEY	int,
	PUB_KEY_key		int,
	QUANTITY		int,
	SALESAMOUNT		numeric
	constraint pk6 primary key (FATCT_KEY)
) 
go

--add foreign key constraints
--alter table [DIM_TITLE]	add constraint fk1 foreign key (TITLE_TYPE_ID)  references DIM_TITLE_TYPE(TITLE_ID)
--alter table [DIM_TITLE]	add constraint fk2 foreign key (PUB_KEY)		references DIM_PUBS(PUB_KEY)
